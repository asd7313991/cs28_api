def k_last_result(code: str) -> str:
    return f"cs28:lottery:{code}:last_result"

def k_history(code: str) -> str:
    return f"cs28:lottery:{code}:history"

def k_current_issue(code: str) -> str:
    return f"cs28:lottery:{code}:current_issue"
